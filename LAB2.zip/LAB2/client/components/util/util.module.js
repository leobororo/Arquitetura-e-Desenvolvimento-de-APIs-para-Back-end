'use strict';

angular.module('myappApp.util', []);
