'use strict';

angular.module('myappApp').config(function ($routeProvider) {
  $routeProvider.when('/', {
    template: '<main></main>'
  });
});
//# sourceMappingURL=main.js.map
