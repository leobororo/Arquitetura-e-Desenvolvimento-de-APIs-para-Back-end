'use strict';

angular.module('myappApp.util', []);
//# sourceMappingURL=util.module.js.map
