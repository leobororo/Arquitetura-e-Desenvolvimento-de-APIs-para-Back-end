/**
 * Locale specific code.
 */
package com.puc.pos.lab01.config.locale;
