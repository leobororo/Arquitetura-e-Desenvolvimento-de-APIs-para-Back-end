/**
 * JPA domain objects.
 */
package com.puc.pos.lab01.domain;
