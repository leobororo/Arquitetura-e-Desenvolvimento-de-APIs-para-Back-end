/**
 * Data Access Objects used by WebSocket services.
 */
package com.puc.pos.lab01.web.websocket.dto;
