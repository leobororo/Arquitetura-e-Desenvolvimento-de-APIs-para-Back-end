package com.puc.pos.lab01.repository;

import com.puc.pos.lab01.domain.Customer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

import static org.springframework.util.StringUtils.isEmpty;

/**
 * Created by Leandro on 6/25/2016.
 */
@Repository
public class CustomerRepositoryImplementation {

    private final Logger log = LoggerFactory.getLogger(CustomerRepositoryImplementation.class);


    @Autowired
    MongoOperations mongoOperations;

    /**
     * Get all customers from the position {from} (inclusive) to position {to} (inclusive)
     * @param from first element's index
     * @param to last elements's index
     * @return list of customers
     */
    public List<Customer> findAllFromTo(@PathVariable Integer from, @PathVariable Integer to) {
        log.debug("Request to get all Customers from the position {from} inclusive to position {to} inclusive");

        Query query = new Query();
        query.limit(to - from + 1);
        query.skip(from);
        return mongoOperations.find(query, Customer.class);
    }

    /**
     * Get all Customers by name and/or site and/or cnpj and/or address
     * @param name the entity's name
     * @param site the entity's site
     * @param cnpj the entity's CNPJ
     * @param address the entity's address
     * @return
     */
    public List<Customer> findByNameAndSiteAndCnpjAndAddress(String name, String site, String cnpj, String address) {
        log.debug("Request to get all Customers by name and/or site and/or cnpj and/or address");

        Query query = new Query();
        if (!isEmpty(name)) {
            query.addCriteria(Criteria.where("name").is(name));
        }
        if (!isEmpty(site)) {
            query.addCriteria(Criteria.where("site").is(site));
        }
        if (!isEmpty(cnpj)) {
            query.addCriteria(Criteria.where("cnpj").is(cnpj));
        }
        if (!isEmpty(address)) {
            query.addCriteria(Criteria.where("address").is(address));
        }
        return mongoOperations.find(query, Customer.class);
    }
}
