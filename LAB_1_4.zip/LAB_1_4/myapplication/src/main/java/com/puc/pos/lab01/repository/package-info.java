/**
 * Spring Data JPA repositories.
 */
package com.puc.pos.lab01.repository;
