package com.puc.pos.lab01.service;

import com.puc.pos.lab01.domain.Customer;
import com.puc.pos.lab01.repository.CustomerRepository;
import com.puc.pos.lab01.repository.CustomerRepositoryImplementation;
import com.puc.pos.lab01.web.rest.dto.CustomerDTO;
import com.puc.pos.lab01.web.rest.mapper.CustomerMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.CriteriaDefinition;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import javax.inject.Inject;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Service Implementation for managing Customer.
 */
@Service
public class CustomerService {

    private final Logger log = LoggerFactory.getLogger(CustomerService.class);

    @Inject
    private CustomerRepository customerRepository;

    @Inject
    private CustomerMapper customerMapper;

    @Autowired
    private CustomerRepositoryImplementation customerRepositoryImplementation;

    /**
     * Save a customer.
     *
     * @param customerDTO the entity to save
     * @return the persisted entity
     */
    public CustomerDTO save(CustomerDTO customerDTO) {
        log.debug("Request to save Customer : {}", customerDTO);
        Customer customer = customerMapper.customerDTOToCustomer(customerDTO);
        customer = customerRepository.save(customer);
        CustomerDTO result = customerMapper.customerToCustomerDTO(customer);
        return result;
    }

    /**
     *  Get all the customers.
     *
     *  @return the list of entities
     */
    public List<Customer> findAll() {
        log.debug("Request to get all Customers");
        List<Customer> result = customerRepository.findAll();
        return result;
    }


    /**
     * Get all customers from the position {from} (inclusive) to position {to} (inclusive)
     * @param from first element's index
     * @param to last elements's index
     * @return list of customers
     */
    public List<Customer> findAllFromTo(@PathVariable Integer from, @PathVariable Integer to) {
        log.debug("Request to get all Customers from the position {from} inclusive to position {to} inclusive");

        List<Customer> customers = null;
        if (from <= to) {
            customers = customerRepositoryImplementation.findAllFromTo(from, to);
        }
        return customers;
    }

    /**
     *  Get one customer by id.
     *
     *  @param id the id of the entity
     *  @return the entity
     */
    public CustomerDTO findOne(String id) {
        log.debug("Request to get Customer : {}", id);
        Customer customer = customerRepository.findOne(id);
        CustomerDTO customerDTO = customerMapper.customerToCustomerDTO(customer);
        return customerDTO;
    }

    /**
     *  Delete the  customer by id.
     *
     *  @param id the id of the entity
     */
    public void delete(String id) {
        log.debug("Request to delete Customer : {}", id);
        customerRepository.delete(id);
    }


    /**
     * Get all the customers whose name, site, CNPJ and address match the request parameters
     * @param name the entity's name
     * @param site the entity's site
     * @param cnpj the entity's CNPJ
     * @param address the entity's address
     * @return the list of customers
     */
    public List<Customer> findByNameSiteCnpjAndAddress(String name, String site, String cnpj, String address) {
        log.debug("Request to get the Customers, name, site, CNPJ and address");
        List<Customer> result = customerRepositoryImplementation.findByNameAndSiteAndCnpjAndAddress(name, site, cnpj, address);
        return result;

    }
}
