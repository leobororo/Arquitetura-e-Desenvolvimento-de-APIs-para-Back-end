/**
 * Swagger api specific code.
 */
package com.puc.pos.lab01.config.apidoc;