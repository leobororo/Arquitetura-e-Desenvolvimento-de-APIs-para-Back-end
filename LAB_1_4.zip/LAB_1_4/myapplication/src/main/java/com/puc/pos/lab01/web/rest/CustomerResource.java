package com.puc.pos.lab01.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.puc.pos.lab01.domain.Customer;
import com.puc.pos.lab01.service.CustomerService;
import com.puc.pos.lab01.web.rest.util.HeaderUtil;
import com.puc.pos.lab01.web.rest.util.PaginationUtil;
import com.puc.pos.lab01.web.rest.dto.CustomerDTO;
import com.puc.pos.lab01.web.rest.mapper.CustomerMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * REST controller for managing Customer.
 */
@RestController
@RequestMapping("/api")
public class CustomerResource {

    private final Logger log = LoggerFactory.getLogger(CustomerResource.class);

    @Inject
    private CustomerService customerService;

    @Inject
    private CustomerMapper customerMapper;

    Pageable pageable;

    /**
     * POST  /customers : Create a new customer.
     *
     * @param customerDTO the customerDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new customerDTO, or with status 400 (Bad Request) if the customer has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/customers",
        method = RequestMethod.POST,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<CustomerDTO> createCustomer(@RequestBody CustomerDTO customerDTO) throws URISyntaxException {
        log.debug("REST request to save Customer : {}", customerDTO);
        if (customerDTO.getId() != null) {
            return ResponseEntity.badRequest().headers(HeaderUtil.createFailureAlert("customer", "idexists", "A new customer cannot already have an ID")).body(null);
        }
        CustomerDTO result = customerService.save(customerDTO);
        return ResponseEntity.created(new URI("/api/customers/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert("customer", result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /customers : Updates an existing customer.
     *
     * @param customerDTO the customerDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated customerDTO,
     * or with status 400 (Bad Request) if the customerDTO is not valid,
     * or with status 500 (Internal Server Error) if the customerDTO couldnt be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @RequestMapping(value = "/customers",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<CustomerDTO> updateCustomer(@RequestBody CustomerDTO customerDTO) throws URISyntaxException {
        log.debug("REST request to update Customer : {}", customerDTO);
        if (customerDTO.getId() == null) {
            return createCustomer(customerDTO);
        }
        CustomerDTO result = customerService.save(customerDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert("customer", customerDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /customers : get all the customers.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of customers in body
     * @throws URISyntaxException if there is an error to generate the pagination HTTP headers
     */
    @RequestMapping(value = "/customers",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<List<CustomerDTO>> getAllCustomers()
        throws URISyntaxException {
        log.debug("REST request to get a page of Customers");
        List<Customer> customers = customerService.findAll();
        return new ResponseEntity<>(customerMapper.customersToCustomerDTOs(customers), HttpStatus.OK);
    }

    /**
     * GET  /customers : get all Customers by name and/or site and/or cnpj and/or address
     *
     * @param name the entity's name
     * @param site the entity's site
     * @param cnpj the entity's CNPJ
     * @param address the entity's address
     * @return the ResponseEntity with status 200 (OK) and the list of customers in body
     * @throws URISyntaxException if there is an error to generate the pagination HTTP headers
     */
    @RequestMapping(value = "/customers/q",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<List<CustomerDTO>> getAllCustomersFiltered(@RequestParam(value="name", required=false) String name,
                                                                     @RequestParam(value="site", required=false) String site,
                                                                     @RequestParam(value="cnpj", required=false) String cnpj,
                                                                     @RequestParam(value="address", required=false) String address)
        throws URISyntaxException {
        log.debug("REST request to get Customers by name, site, CNPJ and address");
        List<Customer> customers = customerService.findByNameSiteCnpjAndAddress(name, site, cnpj, address);
        return new ResponseEntity<>(customerMapper.customersToCustomerDTOs(customers), HttpStatus.OK);
    }

    /**
     * GET  /customers/:id : get the "id" customer.
     *
     * @param id the id of the customerDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the customerDTO, or with status 404 (Not Found)
     */
    @RequestMapping(value = "/customers/{id}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<CustomerDTO> getCustomer(@PathVariable String id) {
        log.debug("REST request to get Customer : {}", id);
        CustomerDTO customerDTO = customerService.findOne(id);
        return Optional.ofNullable(customerDTO)
            .map(result -> new ResponseEntity<>(
                result,
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    /**
     * GET  /customers/:id : get all customers from the position specified by the parameter from inclusive to the
     * position specified by the parameter to inclusive.s
     *
     * @param from first element's index (it starts at 0)
     * @param to last elements's index (it starts at 0)
     * @return the ResponseEntity with status 200 (OK) and the list of customers in body or with status 400 if it was
     * a bad request
     */
    @RequestMapping(value = "/customers/{from}/{to}",
        method = RequestMethod.GET,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<List<CustomerDTO>> getCustomerFromTo(@PathVariable Integer from, @PathVariable Integer to) {
        log.debug("REST request to get Customers from {from} to {to}");
        List<Customer> customers = customerService.findAllFromTo(from, to);

        return Optional.ofNullable(customers)
            .map(result -> new ResponseEntity<>(
                customerMapper.customersToCustomerDTOs(customers),
                HttpStatus.OK))
            .orElse(new ResponseEntity<>(HttpStatus.BAD_REQUEST));
    }

    /**
     * DELETE  /customers/:id : delete the "id" customer.
     *
     * @param id the id of the customerDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @RequestMapping(value = "/customers/{id}",
        method = RequestMethod.DELETE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Void> deleteCustomer(@PathVariable String id) {
        log.debug("REST request to delete Customer : {}", id);
        customerService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("customer", id.toString())).build();
    }

}
