package com.puc.pos.lab01.repository;

import com.puc.pos.lab01.domain.Customer;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

/**
 * Spring Data MongoDB repository for the Customer entity.
 */
@SuppressWarnings("unused")
public interface CustomerRepository extends MongoRepository<Customer,String> {

    List<Customer> findByNameAndSiteAndCnpjAndAddress(String name, String site, String cnpj, String address);

}
