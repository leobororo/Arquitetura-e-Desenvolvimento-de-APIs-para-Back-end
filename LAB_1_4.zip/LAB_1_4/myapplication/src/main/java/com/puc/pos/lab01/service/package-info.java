/**
 * Service layer beans.
 */
package com.puc.pos.lab01.service;
