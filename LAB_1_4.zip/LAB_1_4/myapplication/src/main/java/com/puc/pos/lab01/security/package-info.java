/**
 * Spring Security configuration.
 */
package com.puc.pos.lab01.security;
